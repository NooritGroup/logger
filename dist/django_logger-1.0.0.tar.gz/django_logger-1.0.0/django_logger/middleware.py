import traceback
from logging import getLogger, config
from typing import Optional, Dict

from rest_framework import status
from django.utils.deprecation import MiddlewareMixin

from .dict_loggers import django_logger

config.dictConfig(django_logger)


class LoggerMiddleware(MiddlewareMixin):
    logger = getLogger('django-logger')
    error_name = None

    @staticmethod
    def get_request_data(request) -> Optional[Dict]:
        if request.method == 'DELETE':
            return None
        elif request.method in ('PUT', 'PATCH'):
            request_data = request.POST.dict()
        else:
            request_data = getattr(request, request.method).dict()
        return request_data | request.FILES.dict()

    def doing_log(self, level, msg, **kwargs) -> None:
        getattr(self.logger, level)(msg, extra=kwargs)

    def process_response(self, request, response):
        request_data = LoggerMiddleware.get_request_data(request)
        base_data = {"status_code": response.status_code, "url": request.path, "method": request.method,
                     "user": request.user,
                     "request_data": request_data, "response_data": getattr(response, "data", None),
                     "error_name": None,
                     "module_name": getattr(getattr(request.resolver_match, "func", None), "__name__",
                                            None)}

        if status.is_server_error(response.status_code):
            self.doing_log('critical', response.reason_phrase,
                           **base_data | {"error_name": self.error_name})

        if status.is_client_error(response.status_code):
            self.doing_log('error', response.reason_phrase,
                           **base_data)

        if status.is_success(response.status_code) or status.is_redirect(response.status_code):
            self.doing_log('info', response.reason_phrase,
                           **base_data)
        return response

    def process_exception(self, request, exception):
        self.error_name = traceback.format_exc()
        return None
