MIDDLEWARES = [
    ...
    'logger.middleware.LoggerMiddleware'
] 